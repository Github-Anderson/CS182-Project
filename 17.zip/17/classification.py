import numpy as np
import logging # For a simple logger
from fpgnn.tool import set_predict_argument, get_scaler, load_args, load_data, load_model, split_data, get_metric, get_task_name
from fpgnn.train import predict, compute_score
from fpgnn.data import MoleDataSet # MoleDataSet is used by predict and split_data

# Helper for a simple logger (mimicking train.py's log)
class SimpleLogger:
    def __init__(self, level=logging.INFO):
        self.logger = logging.getLogger("PredictAUCLogger")
        if not self.logger.handlers: # Avoid adding multiple handlers if called multiple times
            self.logger.setLevel(level)
            ch = logging.StreamHandler()
            ch.setLevel(level)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            ch.setFormatter(formatter)
            self.logger.addHandler(ch)

    def info(self, msg):
        self.logger.info(msg)
    def debug(self, msg):
        self.logger.debug(msg)

def predicting_auc(args):
    log = SimpleLogger()
    log.info('Starting AUC ROC calculation on a split of the provided data.')

    # Load training arguments from the saved model to get defaults
    train_args = load_args(args.model_path)
    
    # Merge predict_args with train_args, predict_args take precedence if they exist
    # Then ensure critical args for this specific task are set
    for key, value in vars(train_args).items():
        if not hasattr(args, key): # If predict_args doesn't have it, use train_args
            setattr(args, key, value)

    # Ensure dataset_type is classification and metric is auc for this task
    # These settings are crucial for AUC calculation.
    args.dataset_type = 'classification'
    args.metric = 'auc'
    
    # Set defaults for splitting if not provided in args or train_args
    if not hasattr(args, 'split_type'):
        args.split_type = 'random' 
    if not hasattr(args, 'split_ratio'):
        # Default split: 80% for "train" (to be evaluated), 10% val, 10% test
        args.split_ratio = (0.8, 0.1, 0.1)
    if not hasattr(args, 'seed'):
        args.seed = 0 # Default seed if not in predict_args or train_args

    log.info(f'Loading data from: {args.predict_path}')
    # Data loaded from predict_path MUST have labels for AUC calculation
    evaluation_data = load_data(args.predict_path, args) 
    
    # Get task names and number from the loaded data or train_args
    if not hasattr(args, 'task_names') or not args.task_names:
        args.task_names = evaluation_data.task_names # task_names from MoleDataSet
    if not args.task_names and hasattr(train_args, 'task_names'): # Fallback to train_args
         args.task_names = train_args.task_names
    if not args.task_names: # Final fallback if still not found
        args.task_names = get_task_name(args.predict_path)


    args.task_num = len(args.task_names) if args.task_names else evaluation_data.task_num()


    if args.task_num == 0:
        log.info("Error: Number of tasks is 0. Cannot proceed.")
        return

    log.info(f'Splitting data. Seed: {args.seed}, Type: {args.split_type}, Ratio: {args.split_ratio}')
    # We want to evaluate on the "testing" part of this new split
    train_data_split, val_data_split, test_data_split = split_data(
        data=evaluation_data, 
        type=args.split_type, 
        size=args.split_ratio, 
        seed=args.seed, 
        log=log
    )
    
    if len(test_data_split) == 0:
        log.info("The 'testing' split is empty after splitting. Cannot compute AUC.")
        return

    log.info(f'Size of the split "testing" data for AUC evaluation: {len(test_data_split)}')

    log.info('Loading pre-trained model.')
    model = load_model(args.model_path, args.cuda)
    
    # Scaler should be None for classification tasks. 
    # get_scaler retrieves the scaler saved with the model.
    scaler = get_scaler(args.model_path) 
    if scaler is not None:
        log.info("Warning: A scaler was loaded. For classification AUC, scaler is typically None and will be ignored by the predict function if dataset_type is classification.")

    log.info('Performing predictions on the "testing" split.')
    # Ensure args.batch_size is available for the predict function
    if not hasattr(args, 'batch_size'):
        args.batch_size = getattr(train_args, 'batch_size', 32) # Default batch_size
        
    pred_on_train_split = predict(model, test_data_split, args.batch_size, scaler)
    
    labels_of_train_split = test_data_split.label()
    
    metric_f = get_metric(args.metric) # This will be the AUC function

    log.info('Computing AUC ROC for the "testing" split.')
    auc_scores = compute_score(pred_on_train_split, labels_of_train_split, metric_f, args, log)
    
    average_auc = np.nanmean(auc_scores) # Use nanmean to handle potential NaN scores for some tasks
    
    # Outputting only the requested AUC ROC
    print(f"AUC ROC on the 'testing' split: {average_auc:.6f}")
    if args.task_num > 1 and not np.isnan(average_auc): # Print per-task AUC if multi-task and average is valid
        log.info("Per-task AUC ROC scores:")
        for task_idx, task_name in enumerate(args.task_names):
            if task_idx < len(auc_scores):
                 print(f"  Task '{task_name}': {auc_scores[task_idx]:.6f}")
            else:
                 print(f"  Task '{task_name}': Score not available")


if __name__=='__main__':
    args = set_predict_argument()
    predicting_auc(args)