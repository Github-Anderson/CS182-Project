# ShanghaiTech-CS182-Final-Project
This is the code repository\* for paper *FP-GNN++: Towards Accurate Molecule Property Classification via Leveraging Versatile Features*
![image](figure/teasor.png)
Group ID: 17
Team member:
熊章智: 2023533146 xiongzhzh2023@shanghaitech.edu.cn
陈逸轩: 2023533082 chenyx2023@shanghaitech.edu.cn
杨天倪: 2023533107 yangtn2023@shanghaitech.edu.cn

## Pipeline
![image](figure/pipeline.png)

## Experiment and Ablation Result
![image](figure/experiment.png)
![image](figure/ablation.png)

## Reproduce
### Environment
The most important python packages are:
- python == 3.6.7
- pytorch == 1.2.0
- torch == 0.4.1
- tensorboard == 1.13.1
- rdkit == 2019.09.3
- scikit-learn == 0.22.2.post1
- hyperopt == 0.2.5
- numpy == 1.18.2

For using our model more conveniently, we provide the environment file *<environment.txt>* to install environment directly. Please note that the version of pytorch must be 1.2.0 for version consistency. 

We also provide our local environment files for your reference: *<molecule_env_list.txt>*; *<environment.yaml>*.

### Train from Scratch
We provide all the bash in `bash_script` folder. You can also use `python train.py -h` to see more supported options. If you want to train on the corresponding dataset and splitting type, simply run the corresponding dataset. You can check the dataset and splitting type in the bash file.

For example, you can run: `bash ./bash_script/bash_train_bace_cls_1.sh` to train on `bace` dataset with random splitting type. The program will train and test altogether. 

Note that you don't have to worry about `WARNING: not removing hydrogen atom without neighbors`. This comes from rdkit library and doesn't affect our training. Also for the last four 'sub-tasks' when running and training on dataset `tox21`, following the benchmark convention, they are not considered in either metric evaluation nor training, so there metric number would be `nan` and this is normal. 

### Testing on our trained weight
In the original project code, the training and testing on classification task are both included in one python file. For checking validity conveniently, we provide `classification.py` file to check the performance of our trained weight. You can run `bash ./bash_script/reproduce_random_split.sh` script in the bash_script folder. If you run on slurm cluster, it should be run on computing node otherwise there will be cuda-related error. 

Note that since it is hard to support scaffold split seperately in our `classification.py` due to code engineering complexity, we can only support random split testing. We guarantee that the random split performed between training and classification inference are the same. 

For the sake of being memory-friendly, only the corresponding weights are preserved while the other weights trained on different seeds and scaffold splitting type are not included. 

### Supplementary
We also provide our training log for your reference in `log_reference` folder. Please forgive us that these logs are raw and messy due to fast-approaching deadline. 



If you have problem creating environment, reproducing the result or dealing with unexpected errors, please feel free to drop an email to `xiongzhzh2023@shanghaitech.edu.cn`. Installing environment may be tricky and time-consuming. 
\* Credit: Partial codes are borrowed from github repo: https://github.com/idrugLab/FP-GNN