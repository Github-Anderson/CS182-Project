from .args import set_train_argument, set_predict_argument, set_hyper_argument, set_interfp_argument, set_intergraph_argument
from .tool import *