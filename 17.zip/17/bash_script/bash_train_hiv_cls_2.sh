python train.py  --data_path Data/MoleculeNet/hiv.csv  --dataset_type classification  --save_path model_save/hiv_2_more  --log_path log/hiv_2_more\
 --split_type scaffold --epochs 8 --model_select train --seed 514
