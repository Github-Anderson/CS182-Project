python train.py  --data_path Data/MoleculeNet/sider.csv  --dataset_type classification  --save_path model_save/sider  --log_path log/sider\
 --model_select train --seed 0