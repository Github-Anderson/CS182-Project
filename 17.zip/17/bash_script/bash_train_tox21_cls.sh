python train.py  --data_path Data/MoleculeNet/tox21.csv  --dataset_type classification  --save_path model_save/tox21  --log_path log/tox21\
 --model_select train --epochs 10 --seed 0