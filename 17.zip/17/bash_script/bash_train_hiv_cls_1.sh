python train.py  --data_path Data/MoleculeNet/hiv.csv  --dataset_type classification  --save_path model_save/hiv_1  --log_path log/hiv_1 --epochs 8\
 --model_select train --seed 10