python train.py  --data_path Data/MoleculeNet/bbbp.csv  --dataset_type classification  --save_path model_save/bbbp_1  --log_path log/bbbp_1\
 --model_select train --epochs 10 --seed 0
