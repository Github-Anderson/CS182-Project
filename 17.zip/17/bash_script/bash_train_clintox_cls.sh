python train.py  --data_path Data/MoleculeNet/clintox.csv  --dataset_type classification  --save_path model_save/clintox  --log_path log/clintox --epochs 30\
 --model_select train --seed 0