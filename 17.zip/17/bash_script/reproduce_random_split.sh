python classification.py --predict_path ./Data/MoleculeNet/bace.csv --model_path model_save_reference/bace_1/Seed_0/model.pt
python classification.py --predict_path ./Data/MoleculeNet/bbbp.csv --model_path model_save_reference/bbbp_1/Seed_0/model.pt
python classification.py --predict_path ./Data/MoleculeNet/hiv.csv --model_path model_save_reference/hiv_1/Seed_10/model.pt
python classification.py --predict_path ./Data/MoleculeNet/tox21.csv --model_path model_save_reference/tox21/Seed_0/model.pt
python classification.py --predict_path ./Data/MoleculeNet/clintox.csv --model_path model_save_reference/clintox/Seed_0/model.pt
python classification.py --predict_path ./Data/MoleculeNet/sider.csv --model_path model_save_reference/sider/Seed_0/model.pt